/* Animación de 2 segundos al ingresar a la diapositiva 2 */
(()=>{
const section=document.querySelectorAll('section.slide')[1];
const chart=section?.querySelector('.context-chart');
if(!section||!chart)return;
let active=false;
function visible(){
 const s=getComputedStyle(section),r=section.getBoundingClientRect();
 return s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity)>.05&&r.width>50&&r.height>50&&r.left<innerWidth*.72&&r.right>innerWidth*.28&&r.top<innerHeight*.75&&r.bottom>innerHeight*.25;
}
function check(){const now=visible();if(now&&!active){chart.classList.remove('animar');void chart.offsetWidth;chart.classList.add('animar')}if(!now&&active)chart.classList.remove('animar');active=now}
const obs=new MutationObserver(()=>requestAnimationFrame(check));
for(const el of [document.body,document.getElementById('escenario'),...document.querySelectorAll('section.slide')].filter(Boolean))obs.observe(el,{attributes:true,attributeFilter:['class','style','aria-hidden']});
document.addEventListener('click',()=>setTimeout(check,60));document.addEventListener('keydown',()=>setTimeout(check,60));window.addEventListener('resize',check);window.addEventListener('scroll',check,{passive:true});
setInterval(check,350);check();
})();
